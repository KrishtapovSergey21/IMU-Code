% PSINS Toolbox global variable structure initialization.
% See also  glvf, psinsinit.
% Copyright(c) 2009-2014, by Gongmin Yan, All rights reserved.
% Northwestern Polytechnical University, Xi An, P.R.China
% 14/08/2011, 10/09/2013, 09/03/2014, 22/05/2014
    clear global glv
    global glv
    glv = glvf;
