function data = binmatfile(fname, varname, clm)
% See also  matbinfile.
	data = matbinfile(fname, varname, clm);