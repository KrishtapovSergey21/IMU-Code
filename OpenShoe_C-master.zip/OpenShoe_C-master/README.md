# OpenShoe in C

Original Matlab algorithm from http://www.openshoe.org completely rewritten in C by me.

To see the real-time implementation of this algorithm please see my other repo "OpenShoe_C_Realtime".

I did my best to keep the same file and project structure.

The results are the same between the original algorithm and this one. See the results in the "results" folder.
I used the original data_set_1/data_inert_left.txt for testing.


To plot result.txt use `python3 plotGraph.py`
