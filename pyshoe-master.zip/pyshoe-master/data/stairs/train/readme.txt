Processed MAT files here include:

imu: N x 6 
	-IMU readings for N timesteps

ts: 1 x N 
	- timesteps for the N IMU readings

No ground truth is present here, as this is just raw data that can be considered during 'training'
