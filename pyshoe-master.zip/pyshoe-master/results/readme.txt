run the download script to populate this directory with our trained models, and our results.

The downloaded MAT files have the preprocessed trajectories that are generated for our experiments, which can be recomputed using 'process_error_hallway.py', 'process_error_stairs.py', and 'process_error_vicon.py'

