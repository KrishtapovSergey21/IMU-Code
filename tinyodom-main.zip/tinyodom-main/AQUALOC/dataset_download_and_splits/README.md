# AQUALOC Dataset Download and Splitting Guide:

- Download the dataset from here: http://www.lirmm.fr/aqualoc/
- Put the ```.txt``` files in the dataset home folder.
- Check the ```data_utils.py``` file to see how TinyOdom imports data.
