# GunDog Dataset Download and Splitting Guide:

- Download the training file from here: https://static-content.springer.com/esm/art%3A10.1186%2Fs40317-021-00245-z/MediaObjects/40317_2021_245_MOESM6_ESM.txt . Download the test file from here: https://github.com/Richard6195/Dead-reckoning-animal-movements-in-R/blob/main/Test.Data.P10A.zip 
- Check the ```data_utils.py``` file to see how TinyOdom imports data.
