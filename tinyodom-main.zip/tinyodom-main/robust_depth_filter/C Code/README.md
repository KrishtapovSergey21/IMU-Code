Visit: 

https://github.com/nesl/robust_depth_filter



