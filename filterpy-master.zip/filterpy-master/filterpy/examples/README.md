These examples are vastly out of date. Do not use!

For now look at the code in the test directories. Test code
is written to run with py.test on the command line.

And, of course, refer to my book:
https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python
