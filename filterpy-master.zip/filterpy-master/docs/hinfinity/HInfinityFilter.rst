HInfinityFilter
==================


.. automodule:: filterpy.hinfinity

.. autoclass:: HInfinityFilter
    :members:

    .. automethod:: __init__
