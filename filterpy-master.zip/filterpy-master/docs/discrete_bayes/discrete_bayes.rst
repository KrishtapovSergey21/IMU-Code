Discrete Bayes
==============

words go here

.. automodule:: filterpy.discrete_bayes

-----

.. autofunction:: normalize

-----

.. autofunction:: update

-----

.. autofunction:: predict
