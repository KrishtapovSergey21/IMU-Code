IMM Estimator
================

needs documentation....


-------

.. automodule:: filterpy.kalman




.. autoclass:: IMMEstimator
    :members:    
    
    .. automethod:: __init__

