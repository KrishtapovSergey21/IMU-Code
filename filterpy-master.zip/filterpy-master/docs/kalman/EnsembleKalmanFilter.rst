EnsembleKalmanFilter
=====================

Introduction and Overview
-------------------------

This implements the Ensemble Kalman filter. 

.. automodule:: filterpy.kalman


--------


.. autoclass:: EnsembleKalmanFilter
    :members:

    .. automethod:: __init__
