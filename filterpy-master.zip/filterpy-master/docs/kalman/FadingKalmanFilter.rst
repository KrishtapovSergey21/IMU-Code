FadingKalmanFilter
==================

Implements a fading memory Kalman filter. 


-------

.. automodule:: filterpy.kalman

Fading Memory Kalman filter

.. autoclass:: FadingKalmanFilter
    :members:

    .. automethod:: __init__
