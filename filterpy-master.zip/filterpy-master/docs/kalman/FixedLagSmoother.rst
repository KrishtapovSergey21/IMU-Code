FixedLagSmoother
================

Introduction and Overview
-------------------------

This implements a fixed lag Kalman smoother.


-------

.. automodule:: filterpy.kalman

.. autoclass:: FixedLagSmoother
    :members:

    .. automethod:: __init__
