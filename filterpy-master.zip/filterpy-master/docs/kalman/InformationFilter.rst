InformationFilter
=================

Introduction and Overview
-------------------------

This is a basic implementation of the information filter.


-------

.. automodule:: filterpy.kalman


.. autoclass:: InformationFilter
    :members:

    .. automethod:: __init__
