GHFilter
========

Implements the g-h filter.

-------

.. automodule:: filterpy.gh

.. autoclass:: GHFilter
    :members:

    .. automethod:: __init__
