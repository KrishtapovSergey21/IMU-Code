GHFilterOrder
=============


.. automodule:: filterpy.gh

.. autoclass:: GHFilterOrder
    :members:
    
    .. automethod:: __init__
