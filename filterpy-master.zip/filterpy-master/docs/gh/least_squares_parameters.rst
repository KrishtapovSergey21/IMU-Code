least_squares_parameters
========================


.. automodule:: filterpy.gh

.. autofunction:: least_squares_parameters
