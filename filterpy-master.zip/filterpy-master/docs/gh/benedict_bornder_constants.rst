benedict_bornder_constants
==========================


.. automodule:: filterpy.gh

.. autofunction:: benedict_bornder_constants
