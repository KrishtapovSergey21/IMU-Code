critical_damping_parameters
===========================

.. automodule:: filterpy.gh

.. autofunction:: critical_damping_parameters
