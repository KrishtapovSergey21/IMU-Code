GHKFilter
=========

.. automodule:: filterpy.gh

.. autoclass:: GHKFilter
   :members:

   .. automethod:: __init__  
