optimal_noise_smoothing
=======================


.. automodule:: filterpy.gh

.. autofunction:: optimal_noise_smoothing
