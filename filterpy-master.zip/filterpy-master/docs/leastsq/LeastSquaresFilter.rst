LeastSquaresFilter
==================

.. automodule:: filterpy.leastsq

.. autoclass:: LeastSquaresFilter
    :members:

    .. automethod:: __init__
