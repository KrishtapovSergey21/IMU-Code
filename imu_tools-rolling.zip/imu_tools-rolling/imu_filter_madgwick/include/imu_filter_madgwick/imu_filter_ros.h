/*
 *  Copyright (C) 2010, CCNY Robotics Lab
 *  Ivan Dryanovski <ivan.dryanovski@gmail.com>
 *
 *  http://robotics.ccny.cuny.edu
 *
 *  Based on implementation of Madgwick's IMU and AHRS algorithms.
 *  http://www.x-io.co.uk/node/8#open_source_ahrs_and_imu_algorithms
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_broadcaster.hpp"
#include "tf2_ros/transform_listener.h"
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/vector3_stamped.hpp>
#include <message_filters/subscriber.hpp>
#include <message_filters/sync_policies/approximate_time.hpp>
#include <message_filters/synchronizer.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/magnetic_field.hpp>
#include <tf2/LinearMath/Quaternion.hpp>

#include "imu_filter_madgwick/imu_filter.h"
#include "imu_filter_madgwick/base_node.hpp"
#include "imu_filter_madgwick/visibility_control.h"

class ImuFilterMadgwickRos : public imu_filter::BaseNode
{
    typedef sensor_msgs::msg::Imu ImuMsg;
    typedef sensor_msgs::msg::MagneticField MagMsg;
    typedef geometry_msgs::msg::Vector3Stamped RpyVectorMsg;
    typedef geometry_msgs::msg::PoseStamped PoseMsg;

    typedef message_filters::sync_policies::ApproximateTime<ImuMsg, MagMsg>
        SyncPolicy;
    typedef message_filters::Synchronizer<SyncPolicy> Synchronizer;
    typedef message_filters::Subscriber<ImuMsg> ImuSubscriber;
    typedef message_filters::Subscriber<MagMsg> MagSubscriber;

  public:
    IMU_FILTER_MADGWICK_CPP_PUBLIC
    explicit ImuFilterMadgwickRos(const rclcpp::NodeOptions& options);

    // Reset the filter to the initial state.
    void reset();

    // Callbacks are public so they can be called when used as a library
    void imuCallback(ImuMsg::ConstSharedPtr imu_msg_raw);
    void imuMagCallback(ImuMsg::ConstSharedPtr imu_msg_raw,
                        MagMsg::ConstSharedPtr mag_msg);

  private:
    std::shared_ptr<ImuSubscriber> imu_subscriber_;
    std::shared_ptr<MagSubscriber> mag_subscriber_;
    std::shared_ptr<Synchronizer> sync_;

    rclcpp::Publisher<RpyVectorMsg>::SharedPtr rpy_filtered_debug_publisher_;
    rclcpp::Publisher<RpyVectorMsg>::SharedPtr rpy_raw_debug_publisher_;
    rclcpp::Publisher<ImuMsg>::SharedPtr imu_publisher_;
    rclcpp::Publisher<PoseMsg>::SharedPtr orientation_filtered_publisher_;
    tf2_ros::TransformBroadcaster tf_broadcaster_;
    tf2_ros::Buffer tf_buffer_;
    tf2_ros::TransformListener tf_listener_;

    rclcpp::TimerBase::SharedPtr check_topics_timer_;

    // Subscription for parameter change
    rclcpp::node_interfaces::PostSetParametersCallbackHandle::SharedPtr
        post_set_parameters_callback_handle_;

    // **** paramaters
    WorldFrame::WorldFrame world_frame_;
    bool use_mag_{};
    bool stateless_{};
    bool publish_tf_{};
    bool reverse_tf_{};
    std::string fixed_frame_;
    std::string imu_frame_;
    double constant_dt_;
    bool publish_debug_topics_{};
    bool remove_gravity_vector_{};
    geometry_msgs::msg::Vector3 mag_bias_;
    double orientation_variance_;
    double yaw_offset_total_;
    rclcpp::Duration time_jump_threshold_duration_{0, 0};

    // **** state variables
    std::mutex mutex_;
    bool initialized_;
    rclcpp::Time last_time_;
    rclcpp::Time last_ros_time_;
    tf2::Quaternion yaw_offsets_;

    // **** filter implementation
    ImuFilter filter_;

    // **** member functions
    void publishFilteredMsg(ImuMsg::ConstSharedPtr imu_msg_raw);
    void publishTransform(ImuMsg::ConstSharedPtr imu_msg_raw);
    void publishOrientationFiltered(const ImuMsg& imu_msg);

    void publishRawMsg(const rclcpp::Time& t, float roll, float pitch,
                       float yaw);

    void postSetParametersCallback(
        const std::vector<rclcpp::Parameter>& parameters);
    void checkTopicsTimerCallback();

    void applyYawOffset(double& q0, double& q1, double& q2, double& q3);

    // Check whether ROS time has jumped back. If so, reset the filter.
    void checkTimeJump();
};
