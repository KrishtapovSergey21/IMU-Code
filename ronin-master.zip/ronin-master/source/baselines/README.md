Baseline methods
----------------

Few baseline methods used in our paper are shared here.
We have only shared the data loader for RoNIN dataset. (Please write a custom dataloader to load other data files)

- RIDI (Yan, Hang, Qi Shan, and Yasutaka Furukawa. "RIDI: Robust IMU Double Integration." arXiv preprint arXiv:1712.09004 (2017).)
- PDR: Pedestrian Dead Reckoning
 