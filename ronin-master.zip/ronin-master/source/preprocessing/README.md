Pre_processing
--------------

We have only shared the code for pre_processing a single device, which can be used for prediction. 

Please refer to our paper for the details on the full data collection pipeline. 